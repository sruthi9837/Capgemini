export class account {
    "id": string;
    "Account": string;
    "Available_Cash": string;
    "Todays_Change": any;
}